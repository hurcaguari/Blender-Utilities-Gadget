TEXT = {
    "zh_HANS" : 
    {
        "Model Conversion" : "转换几何",
        "Batch Rendering" : "批量渲染"
        },
    "en_US" : 
    {
        "Model Conversion" : "Model Conversion",
        "Batch Rendering" : "Batch Rendering"
    }
}